package com.vipshop.ussd;

import android.content.Context;
import android.graphics.Color;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/* Transferência manual: número e quantidade em MB, um botão TRANSFERIR. */
public class EnvioView extends LinearLayout {
    private final EditText numero;
    private final EditText quantidade;
    private final TextView estado;

    public EnvioView(Context c) {
        super(c);
        setOrientation(VERTICAL);
        setBackgroundColor(Color.BLACK);
        setPadding(UI.dp(c, 20), UI.dp(c, 12), UI.dp(c, 20), UI.dp(c, 20));

        addView(UI.texto(c, "Transferência manual", 20, UI.OURO));

        LinearLayout cartao = UI.cartao(c);
        cartao.addView(UI.texto(c, "Número (9 dígitos)", 12, UI.CINZA));
        numero = new EditText(c);
        numero.setHint("857730743");
        numero.setTextColor(Color.WHITE);
        numero.setHintTextColor(Color.parseColor("#666666"));
        numero.setInputType(InputType.TYPE_CLASS_NUMBER);
        cartao.addView(numero);

        cartao.addView(UI.texto(c, "Quantidade em MB", 12, UI.CINZA));
        quantidade = new EditText(c);
        quantidade.setHint("512");
        quantidade.setTextColor(Color.WHITE);
        quantidade.setHintTextColor(Color.parseColor("#666666"));
        quantidade.setInputType(InputType.TYPE_CLASS_NUMBER);
        cartao.addView(quantidade);

        Button b = UI.botao(c, "TRANSFERIR");
        b.setOnClickListener(v -> transferir());
        cartao.addView(b);

        estado = UI.texto(c, "", 13, UI.CINZA);
        cartao.addView(estado);
        addView(cartao);
    }

    private void transferir() {
        final String n = numero.getText().toString().trim();
        final String m = quantidade.getText().toString().trim();
        if (!n.matches("8[45]\\d{7}")) {
            estado.setText("O número tem de ter 9 dígitos e começar por 84 ou 85.");
            return;
        }
        if (!m.matches("\\d+")) {
            estado.setText("Escreve a quantidade em MB, só números.");
            return;
        }
        int mbInt = Integer.parseInt(m);
        if (mbInt < 100) {
            estado.setText("Quantidade mínima: 100 MB.");
            return;
        }
        if (mbInt > 10240) {
            estado.setText("Quantidade máxima: 10240 MB.");
            return;
        }
        if (!Config.pronto(getContext())) {
            estado.setText("Falta o token. Abre SISTEMA e cola o token.");
            return;
        }
        estado.setText("A enviar...");
        new Thread(() -> {
            try {
                JSONObject o = new JSONObject(Api.pedir(getContext(), "POST", "/app/enviar", n + " " + m));
                String msg = o.optBoolean("ok")
                        ? "Pedido criado. ID: " + o.optString("id")
                        : "Não foi possível: " + o.optString("erro");
                post(() -> estado.setText(msg));
            } catch (Exception e) {
                String msg = e.getMessage() == null ? "erro desconhecido" : e.getMessage();
                post(() -> estado.setText("Erro: " + msg));
            }
        }).start();
    }
}
