package com.vipshop.ussd;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.provider.Settings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;

/* Sistema: aparelho, licença, servidor e token. */
public class SistemaView extends ScrollView {
    public SistemaView(Context c) {
        super(c);
        setBackgroundColor(Color.BLACK);
        LinearLayout corpo = new LinearLayout(c);
        corpo.setOrientation(LinearLayout.VERTICAL);
        corpo.setPadding(UI.dp(c, 20), UI.dp(c, 12), UI.dp(c, 20), UI.dp(c, 20));
        addView(corpo);

        corpo.addView(UI.texto(c, "Sistema", 20, UI.OURO));

        LinearLayout perfil = UI.cartao(c);
        perfil.addView(UI.texto(c, "ID do aparelho", 11, UI.CINZA));
        String id = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ANDROID_ID);
        perfil.addView(UI.texto(c, id == null ? "-" : id, 14, Color.WHITE));
        perfil.addView(UI.texto(c, "Licença", 11, UI.CINZA));
        perfil.addView(UI.texto(c, UI.tempoRestante(c), 16, UI.VERDE));
        perfil.addView(UI.texto(c, "Servidor", 11, UI.CINZA));
        perfil.addView(UI.texto(c, Config.servidor(c), 13, Color.WHITE));
        perfil.addView(UI.texto(c, "Token", 11, UI.CINZA));
        boolean tem = !Config.token(c).isEmpty();
        perfil.addView(UI.texto(c, tem ? "Definido" : "Em falta", 13, tem ? UI.VERDE : UI.VERMELHO));
        corpo.addView(perfil);

        boolean acess = acessibilidadeAtiva(c);
        perfil.addView(UI.texto(c, "Acessibilidade (leitura do marcador)", 11, UI.CINZA));
        perfil.addView(UI.texto(c, acess ? "Ativa" : "Inativa", 13, acess ? UI.VERDE : UI.VERMELHO));
        Button ab = UI.botao(c, "ABRIR ACESSIBILIDADE");
        ab.setOnClickListener(v -> c.startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)));
        corpo.addView(ab);

        Button b = UI.botao(c, "COLAR TOKEN");
        b.setOnClickListener(v -> pedirToken(c));
        corpo.addView(b);
    }

    static boolean acessibilidadeAtiva(Context c) {
        String ativos = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return ativos != null && ativos.contains(c.getPackageName() + "/" + Acessibilidade.class.getName());
    }

    private void pedirToken(Context c) {
        final EditText t = new EditText(c);
        t.setHint("Token do servidor");
        t.setText(Config.token(c));
        new AlertDialog.Builder(c)
                .setTitle("Token do servidor")
                .setView(t)
                .setPositiveButton("GUARDAR", (d, w) ->
                        Config.p(c).edit().putString("token", t.getText().toString().trim()).apply())
                .setNegativeButton("CANCELAR", null)
                .show();
    }
}
